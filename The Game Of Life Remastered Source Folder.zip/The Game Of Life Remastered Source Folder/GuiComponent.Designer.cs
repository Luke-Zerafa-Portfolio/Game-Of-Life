﻿
namespace The_Game_Of_Life_Remastered
{
    partial class GuiClass
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MainSplit = new System.Windows.Forms.SplitContainer();
            this.SecondarySplit = new System.Windows.Forms.SplitContainer();
            this.CreditsLbl = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.GuideBtn = new System.Windows.Forms.Button();
            this.GenLbl = new System.Windows.Forms.Label();
            this.DeadLbl = new System.Windows.Forms.Label();
            this.AliveLbl = new System.Windows.Forms.Label();
            this.ClearBtn = new System.Windows.Forms.Button();
            this.NextGenBtn = new System.Windows.Forms.Button();
            this.BackgroundCanvas = new System.Windows.Forms.Panel();
            this.ForegroundCanvas = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.MainSplit)).BeginInit();
            this.MainSplit.Panel1.SuspendLayout();
            this.MainSplit.Panel2.SuspendLayout();
            this.MainSplit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SecondarySplit)).BeginInit();
            this.SecondarySplit.Panel1.SuspendLayout();
            this.SecondarySplit.Panel2.SuspendLayout();
            this.SecondarySplit.SuspendLayout();
            this.BackgroundCanvas.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainSplit
            // 
            this.MainSplit.Cursor = System.Windows.Forms.Cursors.VSplit;
            this.MainSplit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainSplit.IsSplitterFixed = true;
            this.MainSplit.Location = new System.Drawing.Point(0, 0);
            this.MainSplit.Name = "MainSplit";
            // 
            // MainSplit.Panel1
            // 
            this.MainSplit.Panel1.Controls.Add(this.SecondarySplit);
            // 
            // MainSplit.Panel2
            // 
            this.MainSplit.Panel2.Controls.Add(this.BackgroundCanvas);
            this.MainSplit.Size = new System.Drawing.Size(1202, 800);
            this.MainSplit.SplitterDistance = 398;
            this.MainSplit.TabIndex = 0;
            // 
            // SecondarySplit
            // 
            this.SecondarySplit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SecondarySplit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SecondarySplit.IsSplitterFixed = true;
            this.SecondarySplit.Location = new System.Drawing.Point(0, 0);
            this.SecondarySplit.Name = "SecondarySplit";
            this.SecondarySplit.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // SecondarySplit.Panel1
            // 
            this.SecondarySplit.Panel1.Controls.Add(this.CreditsLbl);
            // 
            // SecondarySplit.Panel2
            // 
            this.SecondarySplit.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.SecondarySplit.Panel2.Controls.Add(this.textBox2);
            this.SecondarySplit.Panel2.Controls.Add(this.label2);
            this.SecondarySplit.Panel2.Controls.Add(this.label1);
            this.SecondarySplit.Panel2.Controls.Add(this.textBox1);
            this.SecondarySplit.Panel2.Controls.Add(this.checkBox1);
            this.SecondarySplit.Panel2.Controls.Add(this.GuideBtn);
            this.SecondarySplit.Panel2.Controls.Add(this.GenLbl);
            this.SecondarySplit.Panel2.Controls.Add(this.DeadLbl);
            this.SecondarySplit.Panel2.Controls.Add(this.AliveLbl);
            this.SecondarySplit.Panel2.Controls.Add(this.ClearBtn);
            this.SecondarySplit.Panel2.Controls.Add(this.NextGenBtn);
            this.SecondarySplit.Size = new System.Drawing.Size(398, 800);
            this.SecondarySplit.SplitterDistance = 140;
            this.SecondarySplit.TabIndex = 0;
            // 
            // CreditsLbl
            // 
            this.CreditsLbl.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CreditsLbl.Location = new System.Drawing.Point(12, 9);
            this.CreditsLbl.Name = "CreditsLbl";
            this.CreditsLbl.Size = new System.Drawing.Size(298, 85);
            this.CreditsLbl.TabIndex = 0;
            this.CreditsLbl.Text = "The Game Of Life Simulator\r\n\r\nMade by Luke Zerafa 2022";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(117, 288);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(65, 23);
            this.textBox2.TabIndex = 10;
            this.textBox2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnKeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(12, 283);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 28);
            this.label2.TabIndex = 9;
            this.label2.Text = "Grid Size: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 252);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 28);
            this.label1.TabIndex = 8;
            this.label1.Text = "Interval:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(91, 257);
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(56, 23);
            this.textBox1.TabIndex = 7;
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox1.Location = new System.Drawing.Point(12, 219);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(141, 32);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "Activate Tick";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckStateChanged += new System.EventHandler(this.checkBox1_CheckStateChanged);
            // 
            // GuideBtn
            // 
            this.GuideBtn.Font = new System.Drawing.Font("Segoe UI", 80F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.GuideBtn.Location = new System.Drawing.Point(12, 500);
            this.GuideBtn.Name = "GuideBtn";
            this.GuideBtn.Size = new System.Drawing.Size(170, 144);
            this.GuideBtn.TabIndex = 5;
            this.GuideBtn.Text = "?";
            this.GuideBtn.UseVisualStyleBackColor = true;
            this.GuideBtn.Click += new System.EventHandler(this.GuideBtn_Click);
            // 
            // GenLbl
            // 
            this.GenLbl.AutoSize = true;
            this.GenLbl.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.GenLbl.Location = new System.Drawing.Point(76, 73);
            this.GenLbl.Name = "GenLbl";
            this.GenLbl.Size = new System.Drawing.Size(71, 37);
            this.GenLbl.TabIndex = 4;
            this.GenLbl.Text = "Gen:";
            // 
            // DeadLbl
            // 
            this.DeadLbl.AutoSize = true;
            this.DeadLbl.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DeadLbl.Location = new System.Drawing.Point(12, 123);
            this.DeadLbl.Name = "DeadLbl";
            this.DeadLbl.Size = new System.Drawing.Size(62, 28);
            this.DeadLbl.TabIndex = 3;
            this.DeadLbl.Text = "Dead:";
            // 
            // AliveLbl
            // 
            this.AliveLbl.AutoSize = true;
            this.AliveLbl.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AliveLbl.Location = new System.Drawing.Point(12, 151);
            this.AliveLbl.Name = "AliveLbl";
            this.AliveLbl.Size = new System.Drawing.Size(59, 28);
            this.AliveLbl.TabIndex = 2;
            this.AliveLbl.Text = "Alive:";
            // 
            // ClearBtn
            // 
            this.ClearBtn.Location = new System.Drawing.Point(175, 14);
            this.ClearBtn.Name = "ClearBtn";
            this.ClearBtn.Size = new System.Drawing.Size(135, 39);
            this.ClearBtn.TabIndex = 1;
            this.ClearBtn.Text = "Clear";
            this.ClearBtn.UseVisualStyleBackColor = true;
            this.ClearBtn.Click += new System.EventHandler(this.ClearBtn_Click);
            // 
            // NextGenBtn
            // 
            this.NextGenBtn.Location = new System.Drawing.Point(12, 14);
            this.NextGenBtn.Name = "NextGenBtn";
            this.NextGenBtn.Size = new System.Drawing.Size(135, 39);
            this.NextGenBtn.TabIndex = 0;
            this.NextGenBtn.Text = "Next Gen.";
            this.NextGenBtn.UseVisualStyleBackColor = true;
            this.NextGenBtn.Click += new System.EventHandler(this.NextGenBtn_Click);
            // 
            // BackgroundCanvas
            // 
            this.BackgroundCanvas.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundCanvas.Controls.Add(this.ForegroundCanvas);
            this.BackgroundCanvas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BackgroundCanvas.Location = new System.Drawing.Point(0, 0);
            this.BackgroundCanvas.Name = "BackgroundCanvas";
            this.BackgroundCanvas.Size = new System.Drawing.Size(800, 800);
            this.BackgroundCanvas.TabIndex = 0;
            this.BackgroundCanvas.Paint += new System.Windows.Forms.PaintEventHandler(this.OnPaint);
            // 
            // ForegroundCanvas
            // 
            this.ForegroundCanvas.BackColor = System.Drawing.Color.Transparent;
            this.ForegroundCanvas.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.ForegroundCanvas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ForegroundCanvas.Location = new System.Drawing.Point(0, 0);
            this.ForegroundCanvas.Name = "ForegroundCanvas";
            this.ForegroundCanvas.Size = new System.Drawing.Size(800, 800);
            this.ForegroundCanvas.TabIndex = 0;
            this.ForegroundCanvas.Paint += new System.Windows.Forms.PaintEventHandler(this.OnCellsDraw);
            this.ForegroundCanvas.MouseDown += new System.Windows.Forms.MouseEventHandler(this.OnMouseCell);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.OnTick);
            // 
            // GuiClass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1202, 800);
            this.Controls.Add(this.MainSplit);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.MaximizeBox = false;
            this.Name = "GuiClass";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "The Game Of Life";
            this.MainSplit.Panel1.ResumeLayout(false);
            this.MainSplit.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MainSplit)).EndInit();
            this.MainSplit.ResumeLayout(false);
            this.SecondarySplit.Panel1.ResumeLayout(false);
            this.SecondarySplit.Panel2.ResumeLayout(false);
            this.SecondarySplit.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SecondarySplit)).EndInit();
            this.SecondarySplit.ResumeLayout(false);
            this.BackgroundCanvas.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer MainSplit;
        private System.Windows.Forms.SplitContainer SecondarySplit;
        private System.Windows.Forms.Label CreditsLbl;
        private System.Windows.Forms.Button NextGenBtn;
        private System.Windows.Forms.Button ClearBtn;
        private System.Windows.Forms.Panel BackgroundCanvas;
        private System.Windows.Forms.Label AliveLbl;
        private System.Windows.Forms.Label GenLbl;
        private System.Windows.Forms.Label DeadLbl;
        private System.Windows.Forms.Button GuideBtn;
        private System.Windows.Forms.Panel ForegroundCanvas;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
    }
}

