﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Game_Of_Life_Remastered
{
    
    public partial class TheGameOfLifeBook : Form
    {
        List<Entry> EntryList = new List<Entry>();
        int pages = 10;
        int currentPage;
        int tempInput;
        public TheGameOfLifeBook()
        {

            InitializeComponent();
            this.Show();
            
            currentPage = 1;
            EntryList.Add(new Entry("Blinker", "Oscillator", 2, "ImageEntries/Image01.png"));
            EntryList.Add(new Entry("Block", "Still Life", 1, "ImageEntries/Image02.png"));
            EntryList.Add(new Entry("Glider", "Space Ship", 6, "ImageEntries/Image03.png"));
            pages = EntryList.Count;
            PgDisplay.Text = "/" + pages;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pageTurn();
        }
        private void pageTurn()
        {
            pictureBox1.Image = EntryList[currentPage - 1].getThisImage();
            NameLbl.Text = EntryList[currentPage - 1].getName();
            PeriodLbl.Text = EntryList[currentPage - 1].getPeriod().ToString();
            KindLabel.Text = EntryList[currentPage - 1].getType();
        }
        private void PageInput_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                try
                {
                    tempInput = (int.Parse(PageInput.Text));
                    label2.Focus();
                    if (tempInput > pages)
                    {
                        currentPage = pages;
                        PageInput.Text = pages.ToString();
                    }
                    else
                    {
                        currentPage = tempInput;
                        pageTurn();
                        PageInput.Text = tempInput.ToString();
                    }
                    

                }
                
                catch (Exception ex)
                {

                    


                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            currentPage++;
            if(currentPage > pages)
            {
                currentPage = pages;
                
            }
            pageTurn();
            PageInput.Text = currentPage.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            currentPage--;
            if (currentPage <= 1)
            {
                currentPage = 1;
                
            }
            pageTurn();
            PageInput.Text = currentPage.ToString();
        }

        
    }
}
