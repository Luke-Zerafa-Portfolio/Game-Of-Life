﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows.Forms;
namespace The_Game_Of_Life_Remastered
{
    public static class MainClass
    {
        static void Main(string[] args)
        {
            GridBoard board = new GridBoard();
            GridBoard.loadGUI();
        }
        
    }
    /*Code Bacnk:
     * 
            GridBoard.loadGUI();
            Debug.WriteLine("Board Preparing");
     */
}
