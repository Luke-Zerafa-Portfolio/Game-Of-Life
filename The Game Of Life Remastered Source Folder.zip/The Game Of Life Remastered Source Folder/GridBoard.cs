﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Game_Of_Life_Remastered
{
    public class GridBoard
    {
        //Description of class: It contains information about the grid, such as the size and the 
        //gui refrences to the the canvas to draw its component.
        //Checking of neighbouring cells should be done here.
        //There is only ever 1 grid in the entire scene;
        static GuiClass guiGrid;//1 Gui for the entire application
        int size;
        int genCount;
        int countAlive;

        public CellClass[,] grid;
        [STAThread]
        public static void loadGUI()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.Run(guiGrid);
            
        }
        public GridBoard(int sizeSet = 50)
        {
            size = sizeSet;
            grid = new CellClass[size, size];
            clearBoard();
            
            guiGrid = new GuiClass(this);
            
            

            
            


        }
        public void clearBoard()
        {
            setBoard();
        }
        public void setBoard()
        {

            genCount = 0;
            countAlive = 0;
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if(grid[i,j] != null &&grid[i,j].getState())
                    {
                        grid[i, j].setState(false);
                        updateSingleCell(i, j);
                    }
                    
                    grid[i, j] = new CellClass(false);
                    if(j <= 0)//Y axis
                    {
                        grid[i, j].upOpen = false;
                    }
                    if(i <= 0)//X Axis
                    {
                        grid[i, j].leftOpen = false;
                    }
                    if (j >= size-1)
                    {
                        grid[i, j].downOpen = false;
                    }
                    if (i >= size-1)
                    {
                        grid[i, j].rightOpen = false;
                    }
                }
            }
            
            
            
            
        }
        
        public int getAlive()
        {
            return countAlive;
        }
        public int getDead()
        {
            return size * size - countAlive;
        }

        public int currentGen()
        {
            return genCount;
        }

        public void callOutDrawCellsMethod()
        {
            guiGrid.updateAllLabel();
            guiGrid.drawCellOnBitmap();
            //guiGrid.invokeCellGrid();
        }
        private void updateSingleCell(int x,int y)
        {
            guiGrid.updateAllLabel();
            guiGrid.drawSingleCellOnBitmap(x,y);
            guiGrid.updateSingleCell(x, y);
        }
        public int getSize()
        {
            return size;
        }
        public void cellUserInteract(int posX,int posY)
        {
            if(grid[posX,posY].getState())
            {
                grid[posX, posY].setState(false);
                countAlive--;
            }
            else
            {
                grid[posX, posY].setState(true);
                countAlive++;
            }
            updateSingleCell(posX, posY);
            
        }
        public void newGen()
        {
            CellClass[,] newGenCellGrid = new CellClass[size,size];//Copy the contents of the array to not affect the original piece of data.
            int amountOfAliveNeighbours = 0;
            guiGrid.clearDrawList();
            for (int yCount = 0; yCount < size; yCount++)
            {
                for (int xCount = 0; xCount < size; xCount++)
                {
                    newGenCellGrid[xCount, yCount] =(CellClass)grid[xCount, yCount].Clone();
                    
                    amountOfAliveNeighbours = checkForAliveNeighbours(xCount, yCount);
                   // Debug.Write(" | " + newGenCellGrid[xCount, yCount].getState().ToString());
                    if (grid[xCount, yCount].getState())
                    {

                        if (amountOfAliveNeighbours < 2)
                        {
                            newGenCellGrid[xCount, yCount].setState(false);//Dead due to underpopulation
                            countAlive--;
                            guiGrid.addDrawList(xCount, yCount);
                        }
                        else if (amountOfAliveNeighbours > 3)
                        {
                            newGenCellGrid[xCount, yCount].setState(false);//Dead due to overpopulation
                            countAlive--;
                            guiGrid.addDrawList(xCount, yCount);
                        }
                    }
                    else
                    {
                        if (amountOfAliveNeighbours == 3)
                        {
                            newGenCellGrid[xCount, yCount].setState(true);//New Cell due to re
                            //Debug.WriteLine("New Cell: at " + xCount + "," + yCount + ":" + grid[xCount, yCount].getState());
                            countAlive++;
                            guiGrid.addDrawList(xCount, yCount);
                        }
                    }
                    

                }
                //Debug.WriteLine("|");
            }
            grid = newGenCellGrid;
           /* Debug.WriteLine("---------------------");
            for (int yCount = 0; yCount < size; yCount++)
            {
                for (int xCount = 0; xCount < size; xCount++)
                {
                    
                    
                  //  Debug.Write(" | " + grid[xCount, yCount].getState().ToString());
                }
                //Debug.WriteLine(" |");
            }//New Generation will become the current Generation.*/
            genCount++;
            callOutDrawCellsMethod();
        }

        public void setSize(int temp)
        {
            this.size = temp;
            grid = new CellClass[this.size, this.size];
        }

        private int checkForAliveNeighbours(int xCount, int yCount)
        {
            int amountAlive = 0;
            if (grid[xCount,yCount].upOpen)
            {
                
                amountAlive += (grid[xCount, yCount - 1].getState()) ? 1 : 0;
                if (grid[xCount, yCount].rightOpen)
                {
                    amountAlive += (grid[xCount + 1, yCount-1].getState()) ? 1 : 0;
                }
                if (grid[xCount, yCount].leftOpen)
                {
                    amountAlive += (grid[xCount - 1, yCount-1].getState()) ? 1 : 0;
                }
            }
            if(grid[xCount,yCount].downOpen)
            {
                amountAlive += (grid[xCount, yCount + 1].getState()) ? 1 : 0;
                if (grid[xCount, yCount].rightOpen)
                {
                    amountAlive += (grid[xCount + 1, yCount+1].getState()) ? 1 : 0;
                }
                if (grid[xCount, yCount].leftOpen)
                {
                    amountAlive += (grid[xCount - 1, yCount+1].getState()) ? 1 : 0;
                }
            }
            if(grid[xCount,yCount].rightOpen)
            {
                amountAlive += (grid[xCount + 1, yCount].getState()) ? 1 : 0;
            }
            if (grid[xCount, yCount].leftOpen)
            {
                amountAlive += (grid[xCount - 1, yCount].getState()) ? 1 : 0;
            }
            //int worldX, worldY;
            //Grid : 1,1
            //Debug.WriteLine("Checking: "+xCount+","+yCount);
           // Debug.WriteLine("---------------------------");
            /*for (int xOffset = -1; xOffset < 2; xOffset++)
            {
                for (int yOffset = -1; yOffset < 2; yOffset++)
                {
                    if (xOffset == 0 && yOffset == 0)
                    {
                        continue;//Looking at the original Cell, not a neighbour so skip.
                    }
                    worldX = xOffset + xCount;
                    worldY = yOffset + yCount;

                    if (worldX >= 0 && worldX < size && worldY >= 0 && worldY < size)
                    {
                        
                        /*Debug.WriteLineIf((grid[worldX, worldY].getState()), "Alive Neighbours: "+worldX+","+worldY);
                    }

                }
            }*/
            return amountAlive;
        }
    }

}
