﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
namespace The_Game_Of_Life_Remastered
{
    public class CellClass : ICloneable
    {
        //Description of the class: This class should store information about the individual cell.
        //It should not contain other information regarding other cells in the grid
        bool isAlive = false;
        public bool leftOpen = true, rightOpen = true, upOpen = true, downOpen = true;
        
        public CellClass(bool state)
        {
            isAlive = state;
        }
        public bool getState()
        {
            return this.isAlive;
        }
        public void setState(bool val)
        {
            this.isAlive = val;
        }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
/*Code Bank:
 * bool isAlive = false;
        int posX, posY;
        int neighbourCount = 0;
        CellClass[,] neighbours = new CellClass[3, 3];
        public CellClass(bool state,int posX, int posY)
        {
            this.isAlive = state;
            this.posX = posX;
            this.posY = posY;
            this.neighbours[1, 1] = this;
        }
        public bool getState()
        {
            return this.isAlive;
        }
        
        public int getPosX()
        {
            return this.posX;
        }
        public int getPosY()
        {
            return this.posY;
        }
        public void setNeighbour(CellClass cellN, int i ,int j)
        {
            this.neighbours[i, j] = cellN;
            neighbourCount++;
            
        }
        
        public int getNeighbourAlive()
        {
            int count = 0;
            for(int x = 0; x<3;x++)
            {
                for (int y = 0; y < 3; y++)
                {
                    if(x==1 && y==1)
                    {
                        break;
                    }

                    Debug.WriteLine("Checking(X:"+x+"Y:"+y+")");
                        count += (this.neighbours[x,y] != null&&this.neighbours[x, y].getState()) ? 1 : 0;
                    Debug.WriteLine("Count:" + count);
                }
            }
            return count;
        }
 * */