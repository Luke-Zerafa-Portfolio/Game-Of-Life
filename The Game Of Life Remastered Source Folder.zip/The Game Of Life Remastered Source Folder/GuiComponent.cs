﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Game_Of_Life_Remastered
{
    public partial class GuiClass : Form
    {
        //The Class needs information about the board so it requires an object of the board
        static GridBoard board;
        int height;
        int width;
        int size;
        Graphics cellImageG, graphG;
        Bitmap cellImage, graphImage;
        SolidBrush DeadBrush, AliveBrush;
        Pen GridBrush;
        List<Point> cellToUpdate = new List<Point>();
        int temp;
        public GuiClass(GridBoard boardIn)
        {
            board = boardIn;
            size = board.getSize();
            
            GridBrush = new Pen(Color.Gray);
            InitializeComponent();
            updateAllLabel();
            height = BackgroundCanvas.Height;
            width = BackgroundCanvas.Width;
            cellImage = new Bitmap(width, height);
            cellImageG = Graphics.FromImage(cellImage);
            graphImage = new Bitmap(width, height);
            graphG = Graphics.FromImage(graphImage);
            AliveBrush = new SolidBrush(Color.Black);
            DeadBrush = new SolidBrush(Color.White);
            drawGridOnBuffer();
            
        }
        
        private void NextGenBtn_Click(object sender, EventArgs e)
        {
            board.newGen();
        }
        public void addDrawList(int xCordinate, int yCordinate)
        {
            cellToUpdate.Add(new Point(xCordinate, yCordinate));
            //Debug.Write("\nAdded at count = "+cellToUpdate.Count+"\n");
        }
        private void ClearBtn_Click(object sender, EventArgs e)
        {
            Debug.WriteLine("Clear");
            
            board.clearBoard();
            board.callOutDrawCellsMethod();
            invokeCellGrid();
        }
        public void updateAllLabel()
        {
            GenLbl.Text = "Gen: " + board.currentGen();
            AliveLbl.Text = "Alive: " + board.getAlive();
            DeadLbl.Text = "Dead: " + board.getDead();
        }
        private void drawGridOnBuffer()
        {
            GridBrush.Width = 0.000f ;
            graphG.FillRectangle(Brushes.White,0, 0, width, height);
            
            for (int i = 0; i <= size + 1; i++)
            {
                graphG.DrawLine(GridBrush, (i * width / size), 0, (i * width / size), height);
                graphG.DrawLine(GridBrush, 0, (i * height / size), width, (i * height / size));
            }
            
        }
        private void OnPaint(object sender, PaintEventArgs e)
        {
            Graphics backgroundG = e.Graphics;
            backgroundG.DrawImageUnscaled(graphImage, 0, 0);
        }

        

        public void updateSingleCell(int x, int y)
        {
            
            ForegroundCanvas.Invalidate(new Rectangle((x * width / size) + 1,
            (y * height / size)+1, width / size - 1, height / size - 1));
        }

        internal void drawSingleCellOnBitmap(int x, int y)
        {
            CellClass cell;
            float widthOfGrid = GridBrush.Width;
            
            cell = board.grid[x, y];
            
            if (cell.getState())
            {

                cellImageG.FillRectangle(AliveBrush,
            (x * width / size) + widthOfGrid / 2 + 1,
            (y * height / size) + widthOfGrid / 2 +1 , width / size - widthOfGrid / 2 - 1, height / size - widthOfGrid / 2 -1);
            }
            else
            {
                cellImageG.FillRectangle(DeadBrush,
            (x * width / size) + widthOfGrid / 2 + 1,
            (y * height / size) + widthOfGrid / 2 + 1, width / size - widthOfGrid / 2 - 1, height / size - widthOfGrid / 2 - 1);
            }
            
        }

        private void OnMouseCell(object sender, MouseEventArgs e)
        {
            int posX = (e.X * size / width);
            int posY = (e.Y * size / height);
            Debug.WriteLine("Drawing X: "+ posX+ " ,Y: " +posY);
            board.cellUserInteract(posX, posY);
        }

        private void OnTick(object sender, EventArgs e)
        {
            NextGenBtn.PerformClick();
        }
        public void clearDrawList()
        {
            cellToUpdate.Clear();
        }
        private void checkBox1_CheckStateChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked)
            {
                timer1.Start();
            }
            else
            {
                timer1.Stop();
            }
        }


        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            
            if (e.KeyCode == Keys.Enter)
            {

                try
                {
                    temp = (int)(int.Parse(textBox2.Text));
                    if (temp == 0)
                    {
                        throw new InvalidOperationException();
                    }
                    size = temp;
                    board.setSize(temp);
                    board.setBoard();
                    updateAllLabel();
                    drawGridOnBuffer();
                    cellImage = new Bitmap(width, height);
                    cellImageG = Graphics.FromImage(cellImage);
                    BackgroundCanvas.Invalidate();
                    ForegroundCanvas.Invalidate();
                }
                catch (InvalidOperationException x)
                {
                    MessageBox.Show("Number must be greater than 0");
                }
                catch (Exception ex)
                {

                    MessageBox.Show("Must be a number\nError:"+ex.Message);


                }
                

                checkBox1.Focus();
            }
        }



        
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
           
            if(e.KeyCode == Keys.Enter)
            {
                try
                {
                    temp = (int)(float.Parse(textBox1.Text) * 1000);
                    if(temp ==0)
                    {
                        throw new InvalidOperationException();
                    }
                    timer1.Interval = temp;
                    
                }
                catch (InvalidOperationException x)
                {
                    MessageBox.Show("Number must be greater than 0");
                }
                catch (Exception ex)
                {

                    MessageBox.Show("Must be a number");


                }
                checkBox1.Focus();
                e.SuppressKeyPress = true;
                
            }
        }

        private void GuideBtn_Click(object sender, EventArgs e)
        {
            TheGameOfLifeBook book = new TheGameOfLifeBook();
        }

        internal void invokeCellGrid()
        {
            ForegroundCanvas.Invalidate();
        }
        public void drawCellOnBitmap()
        {
            CellClass cell;
            float widthOfGrid = GridBrush.Width;
            for (int cellPointer = 0; cellPointer < cellToUpdate.Count; cellPointer++)
            {
                int x = cellToUpdate[cellPointer].X;
                int y = cellToUpdate[cellPointer].Y;
                cell = board.grid[x, y];
                if (cell == null)
                {
                    continue;
                }
                if (cell.getState())
                {

                    cellImageG.FillRectangle(AliveBrush,
                (x * width / size) + widthOfGrid/2 +1,
                (y * height / size) + widthOfGrid/2 + 1, width / size - widthOfGrid/2 - 1, height / size - widthOfGrid/2 -1);
                }
                else
                {
                    cellImageG.FillRectangle(DeadBrush,
                (x * width / size) + widthOfGrid / 2 + 1,
                (y * height / size) + widthOfGrid / 2 + 1, width / size - widthOfGrid / 2 - 1, height / size - widthOfGrid / 2 - 1);
                }
                updateSingleCell(x, y);
            }
            cellToUpdate.Clear();
        }
        private void OnCellsDraw(object sender, PaintEventArgs e)
        {
            Graphics foregroundG = e.Graphics;
            /*
            */
            foregroundG.DrawImageUnscaled(cellImage, 0, 0);
        }

    }
}
