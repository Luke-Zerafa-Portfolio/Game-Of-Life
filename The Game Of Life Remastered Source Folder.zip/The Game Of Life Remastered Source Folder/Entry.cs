﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace The_Game_Of_Life_Remastered
{
    public class Entry
    {
        string type,name;
        int period;
        Image image;
        public Entry(string name,string type, int period, string path)
        {
            this.name = name;
            this.type = type;
            this.period = period;
            image = Image.FromFile(path);
        }
        public string getType()
        {
            return this.type;
        }
        public string getName()
        {
            return this.name;
        }
        public int getPeriod()
        {
            return this.period;
        }
        public Image getThisImage()
        {
            return this.image;
        }
    }
}
